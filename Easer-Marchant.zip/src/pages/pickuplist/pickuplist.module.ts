import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PickuplistPage } from './pickuplist';

@NgModule({
  declarations: [
    PickuplistPage,
  ],
  imports: [
    IonicPageModule.forChild(PickuplistPage),
  ],
})
export class PickuplistPageModule {}
